import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import { MatSort} from '@angular/material/sort';
import { MatPaginator} from '@angular/material/paginator';
import { MatTableDataSource} from '@angular/material/table';
// @ts-ignore
import * as data from '../../opec.json';
import {MatDialog} from '@angular/material/dialog';
import {EditviewComponent} from './editview/editview.component';

@Component({
  selector: 'app-statement',
  templateUrl: './statement.component.html',
  styleUrls: ['./statement.component.css']
})
export class StatementComponent implements OnInit, AfterViewInit {
@ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  tableData: any;
  tableDataSource  = new MatTableDataSource();
  displayColumns: string[] =   ['0', '1', 'edit', 'delete'];
  constructor(private dialog: MatDialog) {

  }

  ngOnInit() {
    console.log(data.dataset.data);
    // this.tableData = data.dataset.data;
    this.tableDataSource.data = data.dataset.data;
  }
  ngAfterViewInit() {
    this.tableDataSource.paginator = this.paginator;
    this.tableDataSource.sort =  this.sort;
  }
openDialog(obj) {
 const dialogRef = this.dialog.open(EditviewComponent, {
    width: '200px',
      data: {data: obj[0],
    value: obj[1]}
  });
 dialogRef.afterClosed().subscribe(result => {
   console.log('The dialog was closed');
   console.log(result);
  });
}

/*updateRowData(row obj) {
  this.tableDataSource.data = this.tableDataSource.data.filter(value1: any => {
    return value1[0] != row; obj[0];
});
}*/
}
