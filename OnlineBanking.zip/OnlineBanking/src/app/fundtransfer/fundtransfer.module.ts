
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {NeftComponent} from './neft/neft.component';
import {RtgsComponent} from './rtgs/rtgs.component';
import {ImpsComponent} from './imps/imps.component';
import {FundTransferRoutingModule} from './fundtransfer.routing.module';



@NgModule({
  declarations: [
    NeftComponent,
    RtgsComponent,
    ImpsComponent
  ],
  imports: [
    CommonModule,
    FundTransferRoutingModule
  ]
})
export class FundtransferModule { }
