import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private _token: string;
  private _isLoggedIn: boolean;

  public get isLoggedIn(): boolean {
    if(this._token!=null)
        this._isLoggedIn=true
    return this._isLoggedIn;
  }
  public set isLoggedIn(value: boolean) {
    this._isLoggedIn = value;
  }
  public get token(): string {
   
    return this._token;
    window.sessionStorage.setItem("token", this._token);
  }
  public set token(value: string) {
    this._token = value;
  }

  constructor() { }
  logout(){

    window.sessionStorage.removeItem( "token" );
  }
}
