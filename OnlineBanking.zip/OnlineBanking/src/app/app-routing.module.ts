import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import {AccountsummaryComponent} from './accountsummary/accountsummary.component';
import {StatementComponent} from './statement/statement.component';
import {RequestsComponent} from './requests/requests.component';
import {ChequeComponent} from './cheque/cheque.component';
import {AddressComponent} from './address/address.component';
import {DetailedstatementComponent} from './detailedstatement/detailedstatement.component';



const routes: Routes = [
{
  path: 'Login',
  component: LoginComponent
},
{
  path: 'Home',
  component: HomeComponent,
  children: [
    {
      path: 'AccountSummary',
      component: AccountsummaryComponent,
      children: [
        {
          path: 'Statement',
          component: StatementComponent
        },
        {
          path: 'DetailedStatement',
          component: DetailedstatementComponent
        }
      ]

    },
    {
      path: 'Request',
      component: RequestsComponent,
      children: [
        {
          path: 'Cheque',
          component: ChequeComponent
        },
        {
          path: 'Address',
          component: AddressComponent
        }
      ]

    },
    {
      path: 'FundTransfer',
      loadChildren : () => import ('./fundtransfer/fundtransfer.module'). then(m => m.FundtransferModule)
    }
  ]

},


{path: '', redirectTo: '/Login', pathMatch: 'full'},
{path: '**', redirectTo: 'Login'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
