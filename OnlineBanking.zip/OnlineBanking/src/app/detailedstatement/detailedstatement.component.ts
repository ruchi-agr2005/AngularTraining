import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailedstatement',
  templateUrl: './detailedstatement.component.html',
  styleUrls: ['./detailedstatement.component.css']
})
export class DetailedstatementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
