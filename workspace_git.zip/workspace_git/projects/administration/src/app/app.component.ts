import {Component, OnInit} from '@angular/core';
import {UserService} from '../../../util/src/lib/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'administration';
data: any;
  constructor( private userService: UserService) {
  }
  ngOnInit(): void {
    this.data = this.userService.getData();
    console.log(this.data);
  }
}
