import { NgModule } from '@angular/core';
import { UtilComponent } from './util.component';



@NgModule({
  declarations: [UtilComponent],
  imports: [
  ],
  exports: [UtilComponent]
})
export class UtilModule { }
